import json
import os
import sqlite3
import uuid
from datetime import date, datetime
from functools import wraps

from flask import (
    Flask,
    Response,
    flash,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "curora.db")
SCHEMA_PATH = os.path.join(BASE_DIR, "schema.sql")

app = Flask(__name__)
app.secret_key = os.environ.get("CURORA_SECRET_KEY", "curora-phase1-dev-secret-change-in-prod")
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"


# ---------------------------------------------------------------------------
# Database helpers & initial seeding
# ---------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        g.db = conn
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def assign_code(db, table, col, prefix, row_id):
    code = f"{prefix}-{row_id:04d}"
    db.execute(f"UPDATE {table} SET {col} = ? WHERE id = ?", (code, row_id))
    return code


def init_db():
    need_seed = not os.path.exists(DB_PATH)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        conn.executescript(f.read())

    # Seed only if users table is empty
    user_count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    if need_seed or user_count == 0:
        seed_sample_data(conn)
    conn.close()


def seed_sample_data(conn):
    today = date.today().isoformat()

    # Users (Admin + 2 Doctors)
    conn.execute(
        "INSERT INTO users (username, email, full_name, password_hash, role, is_active) VALUES (?, ?, ?, ?, ?, ?)",
        ("admin", "admin@curora.local", "Ananya Sharma (Admin)", generate_password_hash("Admin@123"), "admin", 1),
    )
    doc1_uid = conn.execute(
        "INSERT INTO users (username, email, full_name, password_hash, role, is_active) VALUES (?, ?, ?, ?, ?, ?)",
        ("dr.mehta", "mehta@curora.local", "Dr. Aarav Mehta", generate_password_hash("Doctor@123"), "doctor", 1),
    ).lastrowid
    doc2_uid = conn.execute(
        "INSERT INTO users (username, email, full_name, password_hash, role, is_active) VALUES (?, ?, ?, ?, ?, ?)",
        ("dr.nair", "nair@curora.local", "Dr. Priya Nair", generate_password_hash("Doctor@123"), "doctor", 1),
    ).lastrowid

    # Doctors (2 active, 1 inactive)
    doctors_seed = [
        (doc1_uid, "Dr. Aarav Mehta", "General Medicine", "9876501101", "mehta@curora.local", "Mon–Sat, 09:00–17:00", 1),
        (doc2_uid, "Dr. Priya Nair", "Pediatrics", "9876501102", "nair@curora.local", "Mon–Fri, 10:00–16:00", 1),
        (None, "Dr. Rohan Kapoor", "Orthopedics", "9876501103", "kapoor@curora.local", "On Leave", 0),
    ]
    doc_ids = []
    for uid, name, dept, phone, email, avail, active in doctors_seed:
        cur = conn.execute(
            "INSERT INTO doctors (doctor_code, user_id, full_name, department, phone, email, availability, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (f"TMP-{uuid.uuid4().hex[:8]}", uid, name, dept, phone, email, avail, active),
        )
        assign_code(conn, "doctors", "doctor_code", "DOC", cur.lastrowid)
        doc_ids.append(cur.lastrowid)

    # Patients
    patients_seed = [
        ("Rajesh Kumar", "1986-04-12", "Male", "9811122233", "rajesh.k@example.com", "14 MG Road, Bengaluru", "Sunita Kumar (9811122200)"),
        ("Meera Iyer", "32", "Female", "9822233344", "meera.iyer@example.com", "22 Indiranagar, Bengaluru", "Vikram Iyer (9822233300)"),
        ("Kabir Verma", "2018-09-05", "Male", "9833344455", "", "8 Koramangala, Bengaluru", "Neha Verma (9833344400)"),
    ]
    pat_ids = []
    for name, dob, gender, phone, email, addr, emerg in patients_seed:
        cur = conn.execute(
            "INSERT INTO patients (patient_code, full_name, dob_or_age, gender, phone, email, address, emergency_contact) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (f"TMP-{uuid.uuid4().hex[:8]}", name, dob, gender, phone, email, addr, emerg),
        )
        assign_code(conn, "patients", "patient_code", "PAT", cur.lastrowid)
        pat_ids.append(cur.lastrowid)

    # Appointments
    appts_seed = [
        (pat_ids[0], doc_ids[0], today, "09:30", "Persistent fever and fatigue", "Completed"),
        (pat_ids[1], doc_ids[0], today, "10:30", "Routine blood pressure check", "Scheduled"),
        (pat_ids[2], doc_ids[1], today, "11:00", "Seasonal cough", "Scheduled"),
    ]
    appt_ids = []
    for pid, did, d, t, reason, status in appts_seed:
        cur = conn.execute(
            "INSERT INTO appointments (appointment_code, patient_id, doctor_id, appt_date, appt_time, reason, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (f"TMP-{uuid.uuid4().hex[:8]}", pid, did, d, t, reason, status),
        )
        assign_code(conn, "appointments", "appointment_code", "APT", cur.lastrowid)
        appt_ids.append(cur.lastrowid)

    # Consultation for completed appointment
    conn.execute(
        "INSERT INTO consultations (appointment_id, patient_id, doctor_id, consultation_date, symptoms, diagnosis, treatment_notes) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (
            appt_ids[0],
            pat_ids[0],
            doc_ids[0],
            today,
            "Fever (101F) for 2 days, mild body ache",
            "Acute viral fever",
            "Paracetamol 500mg SOS for fever; hydration and 3 days rest.",
        ),
    )

    # Sample partially paid bill
    cur = conn.execute(
        "INSERT INTO bills (bill_code, patient_id, appointment_id, bill_date, total_amount, paid_amount, status) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (f"TMP-{uuid.uuid4().hex[:8]}", pat_ids[0], appt_ids[0], today, 850.00, 500.00, "Partially Paid"),
    )
    bill_id = cur.lastrowid
    assign_code(conn, "bills", "bill_code", "BILL", bill_id)
    conn.execute("INSERT INTO bill_items (bill_id, description, amount) VALUES (?, ?, ?)", (bill_id, "General Consultation Fee", 600.00))
    conn.execute("INSERT INTO bill_items (bill_id, description, amount) VALUES (?, ?, ?)", (bill_id, "CBC Blood Panel", 250.00))
    conn.execute("INSERT INTO payments (bill_id, payment_date, amount, method) VALUES (?, ?, ?, ?)", (bill_id, today, 500.00, "UPI"))
    conn.commit()


# ---------------------------------------------------------------------------
# Auth & Validation Helpers
# ---------------------------------------------------------------------------
def current_user():
    if "user_id" not in session:
        return None
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id = ? AND is_active = 1", (session["user_id"],)).fetchone()
    if user is None:
        session.clear()
    return user


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if current_user() is None:
            flash("Please sign in to access Curora.", "error")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper


def role_required(*roles):
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            user = current_user()
            if user is None:
                flash("Please sign in to continue.", "error")
                return redirect(url_for("login"))
            if user["role"] not in roles:
                flash("Access denied: you do not have permission for that action.", "error")
                return redirect(url_for("dashboard"))
            return fn(*args, **kwargs)
        return wrapper
    return decorator


@app.context_processor
def inject_globals():
    user = current_user()
    doctor_profile = None
    if user and user["role"] == "doctor":
        doctor_profile = get_db().execute("SELECT * FROM doctors WHERE user_id = ?", (user["id"],)).fetchone()
    return {"current_user": user, "current_doctor": doctor_profile, "today_iso": date.today().isoformat()}


def is_valid_date(val):
    try:
        datetime.strptime(val, "%Y-%m-%d")
        return True
    except (ValueError, TypeError):
        return False


def is_valid_time(val):
    try:
        datetime.strptime(val, "%H:%M")
        return True
    except (ValueError, TypeError):
        return False


# ---------------------------------------------------------------------------
# Routes: Auth & Dashboard
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    if current_user():
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user():
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        identifier = request.form.get("identifier", "").strip()
        password = request.form.get("password", "")
        if not identifier or not password:
            flash("Username/email and password are required.", "error")
            return render_template("login.html")

        db = get_db()
        user = db.execute(
            "SELECT * FROM users WHERE username = ? OR email = ?",
            (identifier, identifier),
        ).fetchone()
        if user is None or not check_password_hash(user["password_hash"], password):
            flash("Invalid username/email or password.", "error")
            return render_template("login.html")
        if user["is_active"] != 1:
            flash("This account has been deactivated. Contact an administrator.", "error")
            return render_template("login.html")

        session.clear()
        session["user_id"] = user["id"]
        session["role"] = user["role"]
        flash(f"Welcome back, {user['full_name']}.", "success")
        return redirect(url_for("dashboard"))
    return render_template("login.html")


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("You have been signed out.", "success")
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    db = get_db()
    user = current_user()
    today = date.today().isoformat()

    if user["role"] == "doctor":
        doc = db.execute("SELECT * FROM doctors WHERE user_id = ?", (user["id"],)).fetchone()
        appts = []
        if doc:
            appts = db.execute(
                """
                SELECT a.*, p.patient_code, p.full_name AS patient_name, p.phone AS patient_phone,
                       c.id AS consultation_id
                FROM appointments a
                JOIN patients p ON p.id = a.patient_id
                LEFT JOIN consultations c ON c.appointment_id = a.id
                WHERE a.doctor_id = ?
                ORDER BY a.appt_date ASC, a.appt_time ASC
                """,
                (doc["id"],),
            ).fetchall()
        today_count = sum(1 for a in appts if a["appt_date"] == today)
        scheduled_count = sum(1 for a in appts if a["status"] == "Scheduled")
        return render_template(
            "dashboard.html",
            doctor=doc,
            doctor_appointments=appts,
            today_count=today_count,
            scheduled_count=scheduled_count,
        )

    counts = {
        "patients": db.execute("SELECT COUNT(*) FROM patients").fetchone()[0],
        "doctors": db.execute("SELECT COUNT(*) FROM doctors WHERE is_active = 1").fetchone()[0],
        "appointments": db.execute("SELECT COUNT(*) FROM appointments").fetchone()[0],
        "today_appointments": db.execute("SELECT COUNT(*) FROM appointments WHERE appt_date = ?", (today,)).fetchone()[0],
    }
    todays_appts = db.execute(
        """
        SELECT a.*, p.patient_code, p.full_name AS patient_name, d.full_name AS doctor_name, d.department
        FROM appointments a
        JOIN patients p ON p.id = a.patient_id
        JOIN doctors d ON d.id = a.doctor_id
        WHERE a.appt_date = ?
        ORDER BY a.appt_time ASC
        """,
        (today,),
    ).fetchall()
    return render_template("dashboard.html", counts=counts, todays_appts=todays_appts)


# ---------------------------------------------------------------------------
# Routes: Admin Staff Account Management
# ---------------------------------------------------------------------------
@app.route("/users", methods=["GET", "POST"])
@role_required("admin")
def users_list():
    db = get_db()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip()
        full_name = request.form.get("full_name", "").strip()
        role = request.form.get("role", "admin").strip()
        password = request.form.get("password", "")
        if not username or not email or not full_name or not password or role not in ("admin", "doctor"):
            flash("All fields are required and role must be Admin or Doctor.", "error")
            return redirect(url_for("users_list"))
        try:
            db.execute(
                "INSERT INTO users (username, email, full_name, password_hash, role, is_active) VALUES (?, ?, ?, ?, ?, 1)",
                (username, email, full_name, generate_password_hash(password), role),
            )
            db.commit()
            flash(f"Staff user '{username}' created.", "success")
        except sqlite3.IntegrityError:
            flash("Username or email already exists.", "error")
        return redirect(url_for("users_list"))

    users = db.execute("SELECT id, username, email, full_name, role, is_active, created_at FROM users ORDER BY id ASC").fetchall()
    return render_template("users.html", users=users)


@app.route("/users/<int:user_id>/update", methods=["POST"])
@role_required("admin")
def user_update(user_id):
    db = get_db()
    action = request.form.get("action")
    user = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    if not user:
        flash("User not found.", "error")
        return redirect(url_for("users_list"))

    if action == "toggle":
        if user["id"] == session["user_id"]:
            flash("You cannot deactivate your own logged-in account.", "error")
        else:
            new_status = 0 if user["is_active"] == 1 else 1
            db.execute("UPDATE users SET is_active = ? WHERE id = ?", (new_status, user_id))
            db.commit()
            flash(f"Updated account status for '{user['username']}'.", "success")
    elif action == "reset_password":
        new_pw = request.form.get("new_password", "")
        if len(new_pw) < 6:
            flash("New password must be at least 6 characters.", "error")
        else:
            db.execute("UPDATE users SET password_hash = ? WHERE id = ?", (generate_password_hash(new_pw), user_id))
            db.commit()
            flash(f"Password reset for '{user['username']}'.", "success")
    elif action == "edit":
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip()
        role = request.form.get("role", user["role"]).strip()
        if not full_name or not email or role not in ("admin", "doctor"):
            flash("Valid name, email, and role are required.", "error")
        else:
            try:
                db.execute("UPDATE users SET full_name = ?, email = ?, role = ? WHERE id = ?", (full_name, email, role, user_id))
                db.commit()
                flash(f"Updated '{user['username']}'.", "success")
            except sqlite3.IntegrityError:
                flash("Email already in use by another user.", "error")
    return redirect(url_for("users_list"))


# ---------------------------------------------------------------------------
# Routes: Patient Management
# ---------------------------------------------------------------------------
@app.route("/patients", methods=["GET", "POST"])
@login_required
def patients_list():
    db = get_db()
    user = current_user()

    if request.method == "POST":
        if user["role"] != "admin":
            flash("Only administrators/reception staff can register patients.", "error")
            return redirect(url_for("patients_list"))

        full_name = request.form.get("full_name", "").strip()
        dob_or_age = request.form.get("dob_or_age", "").strip()
        gender = request.form.get("gender", "").strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip()
        address = request.form.get("address", "").strip()
        emergency_contact = request.form.get("emergency_contact", "").strip()

        if not full_name or not dob_or_age or not phone:
            flash("Full name, date of birth/age, and phone number are required.", "error")
            return redirect(url_for("patients_list"))

        cur = db.execute(
            "INSERT INTO patients (patient_code, full_name, dob_or_age, gender, phone, email, address, emergency_contact) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (f"TMP-{uuid.uuid4().hex[:8]}", full_name, dob_or_age, gender, phone, email, address, emergency_contact),
        )
        code = assign_code(db, "patients", "patient_code", "PAT", cur.lastrowid)
        db.commit()
        flash(f"Patient registered with ID {code}.", "success")
        return redirect(url_for("patient_detail", patient_id=cur.lastrowid))

    q = request.args.get("q", "").strip()
    if q:
        like = f"%{q}%"
        patients = db.execute(
            """
            SELECT * FROM patients
            WHERE full_name LIKE ? OR patient_code LIKE ? OR phone LIKE ?
            ORDER BY id DESC
            """,
            (like, like, like),
        ).fetchall()
    else:
        patients = db.execute("SELECT * FROM patients ORDER BY id DESC").fetchall()
    return render_template("patients.html", patients=patients, q=q)


@app.route("/patients/<int:patient_id>", methods=["GET", "POST"])
@login_required
def patient_detail(patient_id):
    db = get_db()
    user = current_user()
    patient = db.execute("SELECT * FROM patients WHERE id = ?", (patient_id,)).fetchone()
    if not patient:
        flash("Patient not found.", "error")
        return redirect(url_for("patients_list"))

    if request.method == "POST":
        if user["role"] != "admin":
            flash("Only administrators/reception staff can update patient profiles.", "error")
            return redirect(url_for("patient_detail", patient_id=patient_id))

        full_name = request.form.get("full_name", "").strip()
        dob_or_age = request.form.get("dob_or_age", "").strip()
        gender = request.form.get("gender", "").strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip()
        address = request.form.get("address", "").strip()
        emergency_contact = request.form.get("emergency_contact", "").strip()

        if not full_name or not dob_or_age or not phone:
            flash("Full name, date of birth/age, and phone number are required.", "error")
            return redirect(url_for("patient_detail", patient_id=patient_id))

        db.execute(
            """
            UPDATE patients
            SET full_name = ?, dob_or_age = ?, gender = ?, phone = ?, email = ?, address = ?, emergency_contact = ?
            WHERE id = ?
            """,
            (full_name, dob_or_age, gender, phone, email, address, emergency_contact, patient_id),
        )
        db.commit()
        flash("Patient profile updated.", "success")
        return redirect(url_for("patient_detail", patient_id=patient_id))

    appointments = db.execute(
        """
        SELECT a.*, d.full_name AS doctor_name, d.department
        FROM appointments a
        JOIN doctors d ON d.id = a.doctor_id
        WHERE a.patient_id = ?
        ORDER BY a.appt_date DESC, a.appt_time DESC
        """,
        (patient_id,),
    ).fetchall()
    consultations = db.execute(
        """
        SELECT c.*, d.full_name AS doctor_name, a.appointment_code
        FROM consultations c
        JOIN doctors d ON d.id = c.doctor_id
        JOIN appointments a ON a.id = c.appointment_id
        WHERE c.patient_id = ?
        ORDER BY c.consultation_date DESC, c.id DESC
        """,
        (patient_id,),
    ).fetchall()
    return render_template("patient_detail.html", patient=patient, appointments=appointments, consultations=consultations)


# ---------------------------------------------------------------------------
# Routes: Doctor Management
# ---------------------------------------------------------------------------
@app.route("/doctors", methods=["GET", "POST"])
@role_required("admin")
def doctors_list():
    db = get_db()
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        department = request.form.get("department", "").strip()
        phone = request.form.get("phone", "").strip()
        email = request.form.get("email", "").strip()
        availability = request.form.get("availability", "").strip()
        user_id_raw = request.form.get("user_id", "").strip()
        user_id = int(user_id_raw) if user_id_raw.isdigit() else None

        if not full_name or not department or not phone or not availability:
            flash("Doctor name, department, phone, and availability are required.", "error")
            return redirect(url_for("doctors_list"))

        cur = db.execute(
            "INSERT INTO doctors (doctor_code, user_id, full_name, department, phone, email, availability, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)",
            (f"TMP-{uuid.uuid4().hex[:8]}", user_id, full_name, department, phone, email, availability),
        )
        code = assign_code(db, "doctors", "doctor_code", "DOC", cur.lastrowid)
        db.commit()
        flash(f"Doctor added with ID {code}.", "success")
        return redirect(url_for("doctors_list"))

    q = request.args.get("q", "").strip()
    if q:
        like = f"%{q}%"
        doctors = db.execute(
            """
            SELECT d.*, u.username AS linked_username
            FROM doctors d
            LEFT JOIN users u ON u.id = d.user_id
            WHERE d.full_name LIKE ? OR d.department LIKE ? OR d.doctor_code LIKE ?
            ORDER BY d.id DESC
            """,
            (like, like, like),
        ).fetchall()
    else:
        doctors = db.execute(
            """
            SELECT d.*, u.username AS linked_username
            FROM doctors d
            LEFT JOIN users u ON u.id = d.user_id
            ORDER BY d.id DESC
            """
        ).fetchall()
    doctor_users = db.execute("SELECT id, username, full_name FROM users WHERE role = 'doctor' AND is_active = 1").fetchall()
    return render_template("doctors.html", doctors=doctors, doctor_users=doctor_users, q=q)


@app.route("/doctors/<int:doctor_id>/update", methods=["POST"])
@role_required("admin")
def doctor_update(doctor_id):
    db = get_db()
    doctor = db.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,)).fetchone()
    if not doctor:
        flash("Doctor not found.", "error")
        return redirect(url_for("doctors_list"))

    action = request.form.get("action", "edit")
    if action == "toggle":
        new_active = 0 if doctor["is_active"] == 1 else 1
        db.execute("UPDATE doctors SET is_active = ? WHERE id = ?", (new_active, doctor_id))
        db.commit()
        state_lbl = "Active" if new_active == 1 else "Inactive"
        flash(f"{doctor['full_name']} marked as {state_lbl}.", "success")
        return redirect(url_for("doctors_list"))

    full_name = request.form.get("full_name", "").strip()
    department = request.form.get("department", "").strip()
    phone = request.form.get("phone", "").strip()
    email = request.form.get("email", "").strip()
    availability = request.form.get("availability", "").strip()
    user_id_raw = request.form.get("user_id", "").strip()
    user_id = int(user_id_raw) if user_id_raw.isdigit() else None

    if not full_name or not department or not phone or not availability:
        flash("Name, department, phone, and availability are required.", "error")
        return redirect(url_for("doctors_list"))

    db.execute(
        "UPDATE doctors SET user_id = ?, full_name = ?, department = ?, phone = ?, email = ?, availability = ? WHERE id = ?",
        (user_id, full_name, department, phone, email, availability, doctor_id),
    )
    db.commit()
    flash(f"Updated record for {full_name}.", "success")
    return redirect(url_for("doctors_list"))


# ---------------------------------------------------------------------------
# Routes: Appointment Management
# ---------------------------------------------------------------------------
def has_double_booking(db, doctor_id, appt_date, appt_time, exclude_id=0):
    conflict = db.execute(
        """
        SELECT appointment_code FROM appointments
        WHERE doctor_id = ? AND appt_date = ? AND appt_time = ? AND status != 'Cancelled' AND id != ?
        """,
        (doctor_id, appt_date, appt_time, exclude_id),
    ).fetchone()
    return conflict


@app.route("/appointments", methods=["GET", "POST"])
@login_required
def appointments_list():
    db = get_db()
    user = current_user()

    if request.method == "POST":
        if user["role"] != "admin":
            flash("Only administrators/reception staff can create appointments.", "error")
            return redirect(url_for("appointments_list"))

        patient_id = request.form.get("patient_id", type=int)
        doctor_id = request.form.get("doctor_id", type=int)
        appt_date = request.form.get("appt_date", "").strip()
        appt_time = request.form.get("appt_time", "").strip()
        reason = request.form.get("reason", "").strip()

        if not patient_id or not doctor_id or not is_valid_date(appt_date) or not is_valid_time(appt_time):
            flash("Please select a valid patient, doctor, date, and time.", "error")
            return redirect(url_for("appointments_list"))

        patient = db.execute("SELECT id FROM patients WHERE id = ?", (patient_id,)).fetchone()
        doctor = db.execute("SELECT * FROM doctors WHERE id = ?", (doctor_id,)).fetchone()
        if not patient or not doctor:
            flash("Selected patient or doctor does not exist.", "error")
            return redirect(url_for("appointments_list"))
        if doctor["is_active"] != 1:
            flash("Inactive doctors cannot be selected for new appointments.", "error")
            return redirect(url_for("appointments_list"))

        conflict = has_double_booking(db, doctor_id, appt_date, appt_time)
        if conflict:
            flash(
                f"Double-booking conflict: {doctor['full_name']} already has appointment {conflict['appointment_code']} on {appt_date} at {appt_time}.",
                "error",
            )
            return redirect(url_for("appointments_list"))

        cur = db.execute(
            "INSERT INTO appointments (appointment_code, patient_id, doctor_id, appt_date, appt_time, reason, status) VALUES (?, ?, ?, ?, ?, ?, 'Scheduled')",
            (f"TMP-{uuid.uuid4().hex[:8]}", patient_id, doctor_id, appt_date, appt_time, reason),
        )
        code = assign_code(db, "appointments", "appointment_code", "APT", cur.lastrowid)
        db.commit()
        flash(f"Appointment {code} scheduled.", "success")
        return redirect(url_for("appointments_list"))

    # Filters
    f_date = request.args.get("date", "").strip()
    f_doctor = request.args.get("doctor_id", "").strip()
    f_patient = request.args.get("patient_id", "").strip()
    f_status = request.args.get("status", "").strip()

    where = []
    params = []
    if user["role"] == "doctor":
        doc = db.execute("SELECT id FROM doctors WHERE user_id = ?", (user["id"],)).fetchone()
        where.append("a.doctor_id = ?")
        params.append(doc["id"] if doc else -1)
    elif f_doctor.isdigit():
        where.append("a.doctor_id = ?")
        params.append(int(f_doctor))

    if f_date:
        where.append("a.appt_date = ?")
        params.append(f_date)
    if f_patient.isdigit():
        where.append("a.patient_id = ?")
        params.append(int(f_patient))
    if f_status in ("Scheduled", "Completed", "Cancelled"):
        where.append("a.status = ?")
        params.append(f_status)

    sql = """
        SELECT a.*, p.patient_code, p.full_name AS patient_name,
               d.doctor_code, d.full_name AS doctor_name, d.department,
               c.id AS consultation_id
        FROM appointments a
        JOIN patients p ON p.id = a.patient_id
        JOIN doctors d ON d.id = a.doctor_id
        LEFT JOIN consultations c ON c.appointment_id = a.id
    """
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY a.appt_date DESC, a.appt_time ASC"

    appointments = db.execute(sql, params).fetchall()
    patients = db.execute("SELECT id, patient_code, full_name FROM patients ORDER BY full_name ASC").fetchall()
    active_doctors = db.execute("SELECT id, doctor_code, full_name, department FROM doctors WHERE is_active = 1 ORDER BY full_name ASC").fetchall()
    all_doctors = db.execute("SELECT id, doctor_code, full_name, department FROM doctors ORDER BY full_name ASC").fetchall()

    return render_template(
        "appointments.html",
        appointments=appointments,
        patients=patients,
        active_doctors=active_doctors,
        all_doctors=all_doctors,
        f_date=f_date,
        f_doctor=f_doctor,
        f_patient=f_patient,
        f_status=f_status,
    )


@app.route("/appointments/<int:appt_id>/reschedule", methods=["POST"])
@role_required("admin")
def appointment_reschedule(appt_id):
    db = get_db()
    appt = db.execute("SELECT * FROM appointments WHERE id = ?", (appt_id,)).fetchone()
    if not appt:
        flash("Appointment not found.", "error")
        return redirect(url_for("appointments_list"))
    if appt["status"] == "Cancelled":
        flash("Cancelled appointments cannot be rescheduled.", "error")
        return redirect(url_for("appointments_list"))

    new_date = request.form.get("appt_date", "").strip()
    new_time = request.form.get("appt_time", "").strip()
    if not is_valid_date(new_date) or not is_valid_time(new_time):
        flash("Valid date and time are required to reschedule.", "error")
        return redirect(url_for("appointments_list"))

    conflict = has_double_booking(db, appt["doctor_id"], new_date, new_time, exclude_id=appt_id)
    if conflict:
        flash(f"Double-booking conflict with {conflict['appointment_code']} on {new_date} at {new_time}.", "error")
        return redirect(url_for("appointments_list"))

    db.execute("UPDATE appointments SET appt_date = ?, appt_time = ? WHERE id = ?", (new_date, new_time, appt_id))
    db.commit()
    flash(f"Appointment {appt['appointment_code']} rescheduled to {new_date} {new_time}.", "success")
    return redirect(url_for("appointments_list"))


@app.route("/appointments/<int:appt_id>/cancel", methods=["POST"])
@role_required("admin")
def appointment_cancel(appt_id):
    db = get_db()
    appt = db.execute("SELECT * FROM appointments WHERE id = ?", (appt_id,)).fetchone()
    if not appt:
        flash("Appointment not found.", "error")
        return redirect(url_for("appointments_list"))
    db.execute("UPDATE appointments SET status = 'Cancelled' WHERE id = ?", (appt_id,))
    db.commit()
    flash(f"Appointment {appt['appointment_code']} cancelled.", "success")
    return redirect(url_for("appointments_list"))


# ---------------------------------------------------------------------------
# Routes: Basic Consultation / Medical Records
# ---------------------------------------------------------------------------
@app.route("/consultations/<int:appt_id>", methods=["GET", "POST"])
@login_required
def consultation_view(appt_id):
    db = get_db()
    user = current_user()
    appt = db.execute(
        """
        SELECT a.*, p.id AS p_id, p.patient_code, p.full_name AS patient_name, p.dob_or_age, p.gender, p.phone,
               d.id AS d_id, d.full_name AS doctor_name, d.department, d.user_id AS doctor_user_id
        FROM appointments a
        JOIN patients p ON p.id = a.patient_id
        JOIN doctors d ON d.id = a.doctor_id
        WHERE a.id = ?
        """,
        (appt_id,),
    ).fetchone()
    if not appt:
        flash("Appointment not found.", "error")
        return redirect(url_for("appointments_list"))

    if user["role"] == "doctor" and appt["doctor_user_id"] != user["id"]:
        flash("Access denied: this appointment is not assigned to you.", "error")
        return redirect(url_for("dashboard"))

    existing = db.execute("SELECT * FROM consultations WHERE appointment_id = ?", (appt_id,)).fetchone()

    if request.method == "POST":
        if user["role"] != "doctor":
            flash("Only the assigned doctor can add or update consultation notes.", "error")
            return redirect(url_for("consultation_view", appt_id=appt_id))
        if appt["status"] == "Cancelled":
            flash("Cannot record consultation for a cancelled appointment.", "error")
            return redirect(url_for("consultation_view", appt_id=appt_id))

        c_date = request.form.get("consultation_date", "").strip()
        symptoms = request.form.get("symptoms", "").strip()
        diagnosis = request.form.get("diagnosis", "").strip()
        treatment_notes = request.form.get("treatment_notes", "").strip()
        mark_completed = request.form.get("mark_completed") == "1"

        if not is_valid_date(c_date) or not symptoms or not diagnosis or not treatment_notes:
            flash("Consultation date, symptoms, diagnosis, and treatment notes are required.", "error")
            return redirect(url_for("consultation_view", appt_id=appt_id))

        if existing:
            db.execute(
                """
                UPDATE consultations
                SET consultation_date = ?, symptoms = ?, diagnosis = ?, treatment_notes = ?, updated_at = CURRENT_TIMESTAMP
                WHERE appointment_id = ?
                """,
                (c_date, symptoms, diagnosis, treatment_notes, appt_id),
            )
        else:
            db.execute(
                """
                INSERT INTO consultations (appointment_id, patient_id, doctor_id, consultation_date, symptoms, diagnosis, treatment_notes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (appt_id, appt["p_id"], appt["d_id"], c_date, symptoms, diagnosis, treatment_notes),
            )

        if mark_completed:
            db.execute("UPDATE appointments SET status = 'Completed' WHERE id = ?", (appt_id,))

        db.commit()
        flash("Consultation notes saved.", "success")
        return redirect(url_for("consultation_view", appt_id=appt_id))

    previous_consultations = db.execute(
        """
        SELECT c.*, d.full_name AS doctor_name, a.appointment_code
        FROM consultations c
        JOIN doctors d ON d.id = c.doctor_id
        JOIN appointments a ON a.id = c.appointment_id
        WHERE c.patient_id = ? AND c.appointment_id != ?
        ORDER BY c.consultation_date DESC, c.id DESC
        """,
        (appt["p_id"], appt_id),
    ).fetchall()

    return render_template(
        "consultation.html",
        appt=appt,
        existing=existing,
        previous_consultations=previous_consultations,
    )


# ---------------------------------------------------------------------------
# Routes: Billing & Payments
# ---------------------------------------------------------------------------
@app.route("/billing", methods=["GET", "POST"])
@role_required("admin")
def billing_list():
    db = get_db()
    if request.method == "POST":
        patient_id = request.form.get("patient_id", type=int)
        appointment_id_raw = request.form.get("appointment_id", "").strip()
        appointment_id = int(appointment_id_raw) if appointment_id_raw.isdigit() else None
        bill_date = request.form.get("bill_date", "").strip()
        descriptions = request.form.getlist("item_description[]")
        amounts_raw = request.form.getlist("item_amount[]")

        if not patient_id or not is_valid_date(bill_date):
            flash("Valid patient and bill date are required.", "error")
            return redirect(url_for("billing_list"))

        items = []
        for desc, amt_str in zip(descriptions, amounts_raw):
            desc = desc.strip()
            if not desc and not amt_str.strip():
                continue
            try:
                amt = round(float(amt_str), 2)
            except (ValueError, TypeError):
                flash("Charge amounts must be valid numbers.", "error")
                return redirect(url_for("billing_list"))
            if not desc or amt < 0:
                flash("Each line item requires a description and non-negative amount.", "error")
                return redirect(url_for("billing_list"))
            items.append((desc, amt))

        if not items:
            flash("Please add at least one charge line item.", "error")
            return redirect(url_for("billing_list"))

        total = round(sum(amt for _, amt in items), 2)
        cur = db.execute(
            "INSERT INTO bills (bill_code, patient_id, appointment_id, bill_date, total_amount, paid_amount, status) VALUES (?, ?, ?, ?, ?, 0, 'Unpaid')",
            (f"TMP-{uuid.uuid4().hex[:8]}", patient_id, appointment_id, bill_date, total),
        )
        bill_id = cur.lastrowid
        code = assign_code(db, "bills", "bill_code", "BILL", bill_id)
        for desc, amt in items:
            db.execute("INSERT INTO bill_items (bill_id, description, amount) VALUES (?, ?, ?)", (bill_id, desc, amt))
        db.commit()
        flash(f"Bill {code} created (Total: ₹{total:.2f}).", "success")
        return redirect(url_for("bill_detail", bill_id=bill_id))

    bills = db.execute(
        """
        SELECT b.*, p.patient_code, p.full_name AS patient_name, a.appointment_code
        FROM bills b
        JOIN patients p ON p.id = b.patient_id
        LEFT JOIN appointments a ON a.id = b.appointment_id
        ORDER BY b.id DESC
        """
    ).fetchall()
    patients = db.execute("SELECT id, patient_code, full_name FROM patients ORDER BY full_name ASC").fetchall()
    appointments = db.execute(
        """
        SELECT a.id, a.appointment_code, a.appt_date, a.patient_id, p.full_name AS patient_name
        FROM appointments a
        JOIN patients p ON p.id = a.patient_id
        WHERE a.status != 'Cancelled'
        ORDER BY a.appt_date DESC, a.id DESC
        """
    ).fetchall()
    return render_template("billing.html", bills=bills, patients=patients, appointments=appointments)


@app.route("/billing/<int:bill_id>", methods=["GET", "POST"])
@role_required("admin")
def bill_detail(bill_id):
    db = get_db()
    bill = db.execute(
        """
        SELECT b.*, p.patient_code, p.full_name AS patient_name, p.phone AS patient_phone, p.address AS patient_address,
               a.appointment_code, a.appt_date
        FROM bills b
        JOIN patients p ON p.id = b.patient_id
        LEFT JOIN appointments a ON a.id = b.appointment_id
        WHERE b.id = ?
        """,
        (bill_id,),
    ).fetchone()
    if not bill:
        flash("Bill not found.", "error")
        return redirect(url_for("billing_list"))

    if request.method == "POST":
        payment_date = request.form.get("payment_date", "").strip()
        method = request.form.get("method", "").strip()
        try:
            amount = round(float(request.form.get("amount", "")), 2)
        except (ValueError, TypeError):
            amount = 0

        balance = round(bill["total_amount"] - bill["paid_amount"], 2)
        if not is_valid_date(payment_date) or method not in ("Cash", "Card", "UPI") or amount <= 0:
            flash("Enter a valid payment date, positive amount, and payment method.", "error")
            return redirect(url_for("bill_detail", bill_id=bill_id))
        if amount > balance:
            flash(f"Payment exceeds remaining balance due (₹{balance:.2f}).", "error")
            return redirect(url_for("bill_detail", bill_id=bill_id))

        db.execute(
            "INSERT INTO payments (bill_id, payment_date, amount, method) VALUES (?, ?, ?, ?)",
            (bill_id, payment_date, amount, method),
        )
        new_paid = round(bill["paid_amount"] + amount, 2)
        if new_paid <= 0:
            new_status = "Unpaid"
        elif new_paid < bill["total_amount"]:
            new_status = "Partially Paid"
        else:
            new_status = "Paid"

        db.execute("UPDATE bills SET paid_amount = ?, status = ? WHERE id = ?", (new_paid, new_status, bill_id))
        db.commit()
        flash(f"Recorded payment of ₹{amount:.2f} via {method}. Status: {new_status}.", "success")
        return redirect(url_for("bill_detail", bill_id=bill_id))

    items = db.execute("SELECT * FROM bill_items WHERE bill_id = ? ORDER BY id ASC", (bill_id,)).fetchall()
    payments = db.execute("SELECT * FROM payments WHERE bill_id = ? ORDER BY payment_date ASC, id ASC", (bill_id,)).fetchall()
    return render_template("bill_detail.html", bill=bill, items=items, payments=payments)


# ---------------------------------------------------------------------------
# Routes: Basic Backup / Export (Section 6)
# ---------------------------------------------------------------------------
@app.route("/backup/export")
@role_required("admin")
def backup_export():
    db = get_db()
    tables = ["users", "patients", "doctors", "appointments", "consultations", "bills", "bill_items", "payments"]
    export_data = {"exported_at": datetime.utcnow().isoformat() + "Z", "tables": {}}
    for tbl in tables:
        rows = db.execute(f"SELECT * FROM {tbl}").fetchall()
        records = []
        for r in rows:
            d = dict(r)
            if tbl == "users":
                d.pop("password_hash", None)
            records.append(d)
        export_data["tables"][tbl] = records

    return Response(
        json.dumps(export_data, indent=2),
        mimetype="application/json",
        headers={"Content-Disposition": f"attachment; filename=curora-backup-{date.today().isoformat()}.json"},
    )


if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="127.0.0.1", port=5000)