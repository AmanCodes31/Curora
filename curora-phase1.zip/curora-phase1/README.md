# Curora HMS — Phase 1

A Flask + SQLite hospital management system assembled from the supplied backend and base template, with the missing schema, page templates, and stylesheet added.

## Requirements
- Python 3.10+
- pip

## Run on Windows
1. Extract `curora-phase1.zip`.
2. Open Command Prompt or PowerShell in the extracted `curora-phase1` folder.
3. Create and activate a virtual environment (recommended):
   ```powershell
   py -m venv .venv
   .\.venv\Scripts\activate
   ```
4. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
5. Start the app:
   ```powershell
   python app.py
   ```
6. Open http://127.0.0.1:5000 in your browser.

The SQLite database (`curora.db`) is created automatically on first launch and sample data is seeded.

## Demo logins
- Admin: `admin` / `Admin@123`
- Doctor: `dr.mehta` / `Doctor@123`
- Doctor: `dr.nair` / `Doctor@123`

Change these passwords and set a strong `CURORA_SECRET_KEY` before any real deployment.

## Included modules
- Role-based admin and doctor login
- Dashboard
- Patient registration, search, and profiles
- Doctor directory and linked doctor accounts
- Appointment scheduling, filtering, rescheduling, and cancellation
- Doctor consultation notes and previous visit history
- Billing, line items, payment recording, and bill history
- JSON database backup export

## Important limitations
This is a Phase 1 demonstration project, not a production-ready clinical system. It does not include deployment hardening, CSRF protection, audit logging, encryption at rest, automated backups, or regulatory compliance controls. Do not enter real patient/medical data until it has been reviewed and secured appropriately.
